package com.example.holiday;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolidayApplicationTests {

    @Test
    void contextLoads() {
    }

}
