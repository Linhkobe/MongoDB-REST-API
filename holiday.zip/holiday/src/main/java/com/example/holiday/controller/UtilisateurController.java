package com.example.holiday.controller;

import com.example.holiday.model.Article;
import com.example.holiday.model.Utilisateur;
import com.example.holiday.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/utilisateurs")
public class UtilisateurController {

    @Autowired
    private UtilisateurService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Utilisateur createUser(@RequestBody Utilisateur utilisateur) {
        return service.addUtilisateur(utilisateur);
    }

    /// worked and verified on browser
    @GetMapping
    public List<Utilisateur> getUser(){
        return service.findAllUtilisateur();
    }

    /// worked and verified on browser
    @GetMapping("/{_id}")
    public Utilisateur findUserByUserId(@PathVariable String _id){
        return service.getUtilisateurByUtilisateurId(_id);
    }

    /// worked and verified on browser
    @GetMapping("/nom/{nom}")
    public Utilisateur findUserByNom(@PathVariable String nom){

        return service.getUtilisateurByNom(nom);
    }

    @GetMapping("/prenom/{prenom}")
    public Utilisateur findUserByPrenom(@PathVariable String prenom){

        return service.getUtilisateurByPrenom(prenom);
    }

    @GetMapping("/email/{email}")
    public Utilisateur findUserByEmail(@PathVariable String email){

        return service.getUtilisateurByEmail(email);
    }

    /// worked and verified on postman
    @PutMapping
    public Utilisateur modifyUtilisateur(@RequestBody Utilisateur utilisateur) {
        return service.updateUtilisateur(utilisateur);
    }

    /// worked and verified on postman
    @DeleteMapping("/{nom}")
    public String deleteUtilisateur(@PathVariable String nom) {
        return service.deleteUtilisateur(nom);
    }
}
