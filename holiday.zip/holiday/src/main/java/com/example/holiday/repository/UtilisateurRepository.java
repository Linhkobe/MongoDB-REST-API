package com.example.holiday.repository;

import com.example.holiday.model.Utilisateur;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface UtilisateurRepository extends MongoRepository<Utilisateur, String> {

    @Query("{nom:?0}")
    Utilisateur findByNom(String nom);

    void deleteByNom(String nom);

    @Query("{email:?0}")
    Utilisateur findByEmail(String email);
    @Query("{prenom:?0}")
    Utilisateur findByPrenom(String prenom);
}
