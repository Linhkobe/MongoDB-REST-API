package com.example.holiday.service;

import com.example.holiday.model.Article;
import com.example.holiday.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ArticleService {

    @Autowired
    private ArticleRepository repository;

    // CRUD OPERATIONS :

    // CREATE
    public Article addArticle(Article article) {
        article.setArticleId(UUID.randomUUID().toString().split("-")[0]);
        return repository.save(article);
    }

    // READ
    public List<Article> findAllArticle() {
        return repository.findAll();
    }

    /// Get article by article id
    public  Article getArticleByArticleId(String articleId) {
        return repository.findById(articleId).get();
    }

    /// Get article by fournisseur
    public List<Article> getArticleByFournisseur(String nomFournisseur) {
        return repository.findByNomFournisseur(nomFournisseur);
    }

    public  List<Article> getArticleByNomArticle(String nomArticle) {
        return repository.findArticleByNomArticle(nomArticle);
    }

    // UPDATE
    public  Article updateArticle(Article articleRequest){
        ///get the existing document from DB
        Article existingArticle = repository.findById(articleRequest.getArticleId()).get();
        existingArticle.setNomFournisseur(articleRequest.getNomFournisseur());
        existingArticle.setPrix(articleRequest.getPrix());
        existingArticle.setQuantité(articleRequest.getQuantité());
        existingArticle.setNomArticle(articleRequest.getNomArticle());
        return repository.save(existingArticle);
    }

    // DELETE
    public String deleteArticle(String articleId) {
        repository.deleteById(articleId);
        return "Article " + articleId + " a été supprimé";
    }

}
