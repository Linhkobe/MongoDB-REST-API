package com.example.holiday.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "fournisseur")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Fournisseur {

    @Id
    private String fournisseurId;
    private String nomFournisseur;
    private String prenom;
    private String adresse;
    private String email;

}
