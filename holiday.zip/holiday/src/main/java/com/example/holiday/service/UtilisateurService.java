package com.example.holiday.service;

import com.example.holiday.model.Article;
import com.example.holiday.model.Fournisseur;
import com.example.holiday.model.Utilisateur;
import com.example.holiday.repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UtilisateurService {

    @Autowired
    private UtilisateurRepository repository;

    ///*  CRUD OPERATIONS *///

    // CREATE
    public Utilisateur addUtilisateur(Utilisateur utilisateur) {
        utilisateur.set_id(UUID.randomUUID().toString().split("_")[0]);
//        utilisateur.set_Id(UUID.randomUUID().toString();
        return repository.save(utilisateur);
    }

    // READ
    public List<Utilisateur> findAllUtilisateur(){
        return repository.findAll();
    }

    /// Find user by ID
    public Utilisateur getUtilisateurByUtilisateurId(String utilisateurId){
        return repository.findById(utilisateurId).get();
    }

    /// Find user by nom
    public Utilisateur getUtilisateurByNom(String nom){
        return repository.findByNom(nom);
    }

    // UPDATE
    public Utilisateur updateUtilisateur(Utilisateur utilisateurRequest){
        ///get the existing document from DB
//        Utilisateur existingUtilisateur = repository.findById(utilisateurRequest.getUtilisateurId()).get();
        Utilisateur existingUtilisateur = repository.findById(utilisateurRequest.get_id()).get();
        existingUtilisateur.setPrenom(utilisateurRequest.getPrenom());
        existingUtilisateur.setNom(utilisateurRequest.getNom());
        existingUtilisateur.setEmail(utilisateurRequest.getEmail());
        existingUtilisateur.setPassword(utilisateurRequest.getPassword());
        return repository.save(existingUtilisateur);
    }

    // DELETE
    public String deleteUtilisateur(String nom) {
        repository.deleteByNom(nom);
        return "Utilisateur " + nom + " a été supprimé";
    }

    public Utilisateur getUtilisateurByEmail(String email) {
        return repository.findByEmail(email);
    }

    public Utilisateur getUtilisateurByPrenom(String prenom) {
        return repository.findByPrenom(prenom);
    }
}
