package com.example.holiday.service;

import com.example.holiday.model.Fournisseur;
import com.example.holiday.repository.FournisseurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class FournisseurService {

    @Autowired
    private FournisseurRepository repository;

    // CRUD OPERATIONS :

    // CREATE
    public Fournisseur addFournisseur(Fournisseur fournisseur) {
        fournisseur.setFournisseurId(UUID.randomUUID().toString().split("-")[0]);
        return repository.save(fournisseur);
    }

    // READ
    public List<Fournisseur> findAllFournisseur() {
        return repository.findAll();
    }

    /// Get fournisseur by fournisseur id

    public Fournisseur getFournisseurByFournisseurId(String fournisseurId) {
        return repository.findById(fournisseurId).get();
    }

    /// Get fournisseur by addresse
    public Fournisseur getFournisseurByAdresse(String adrese) {
        return repository.findByAdresse(adrese);
    }

    public List<Fournisseur> getFournisseurByNom(String nomFournisseur) {
        return repository.findFournisseurByNom(nomFournisseur);
    }

    public Fournisseur getFournisseurByPrenom(String prenom) {
        return repository.findFournisseurByPrenom(prenom);
    }

    public Fournisseur getFournisseurByEmail(String email) {
        return repository.findFournisseurByEmail(email);
    }

    // UPDATE
    public Fournisseur updateFournisseur(Fournisseur fournisseurRequest){
        ///get the existing document from DB
        Fournisseur existingFournisseur = repository.findById(fournisseurRequest.getFournisseurId()).get();
        existingFournisseur.setNomFournisseur (fournisseurRequest.getNomFournisseur());
        existingFournisseur.setEmail(fournisseurRequest.getEmail());
        existingFournisseur.setAdresse (fournisseurRequest.getAdresse());
        existingFournisseur.setPrenom(fournisseurRequest.getPrenom());
        return repository.save(existingFournisseur);
    }

    // DELETE
    public String deleteFournisseur(String fournisseurId) {
        repository.deleteById(fournisseurId);
        return "Fournisseur "+ fournisseurId +" a été supprimé";
    }
}

