package com.example.holiday.repository;

import com.example.holiday.model.Article;
import com.example.holiday.model.Fournisseur;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface FournisseurRepository extends MongoRepository<Fournisseur, String> {

    @Query("{prenom:?0}")
    Fournisseur findFournisseurByPrenom(String prenom);
    @Query("{email:?0}")
    Fournisseur findFournisseurByEmail(String email);
    @Query("{adresse:?0}")
    Fournisseur findByAdresse(String adrese);
    @Query("{nomFournisseur:?0}")
    List<Fournisseur> findFournisseurByNom(String nomFournisseur);
}
