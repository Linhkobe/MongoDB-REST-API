package com.example.holiday.controller;

import com.example.holiday.model.Article;
import com.example.holiday.model.Fournisseur;
import com.example.holiday.service.FournisseurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/fournisseurs")
public class FournisseurController {

    @Autowired
    private FournisseurService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Fournisseur createFournisseur(@RequestBody Fournisseur fournisseur) {
        return service.addFournisseur(fournisseur);
    }

    /// worked and verified on browser
    @GetMapping
    public List<Fournisseur> getFournisseur() {
        return service.findAllFournisseur();
    }

    /// worked and verified on browser
    @GetMapping("/fournisseur/{fournisseurId}")
    public Fournisseur getFournisseur(@PathVariable String fournisseurId) {
        return service.getFournisseurByFournisseurId(fournisseurId);
    }

    /// worked and verified on browser
    @GetMapping("/nomFournisseur/{nomFournisseur}")
    public List<Fournisseur> findFournisseurByNom(@PathVariable String nomFournisseur) {
        return service.getFournisseurByNom(nomFournisseur);
    }

    /// worked and verified on browser
    @GetMapping("/prenom/{prenom}")
    public Fournisseur findFournisseurByPrenom(@PathVariable String prenom) {
        return service.getFournisseurByPrenom(prenom);
    }

    /// worked and verified on browser
    @GetMapping("/adresse/{adresse}")
    public Fournisseur findFournisseurByAdresse(@PathVariable String adresse) {
        return service.getFournisseurByAdresse(adresse);
    }

    /// worked and verified on postman
    @PutMapping
    public Fournisseur modifyFournisseur(@RequestBody Fournisseur fournisseur) {
        return service.updateFournisseur(fournisseur);
    }

    /// worked and verified on postman
    @DeleteMapping("/{fournisseurId}")
    public  String deleteFournisseur(@PathVariable String fournisseurId) {
        return service.deleteFournisseur(fournisseurId);
    }
}

