package com.example.holiday.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "utilisateur")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Utilisateur {

    private String _id;
    private String nom;
    private String prenom;
    private String email;
    private String password;

}
