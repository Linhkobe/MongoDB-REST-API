package com.example.holiday.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "article")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Article {

    @Id
    private String articleId;
    private String nomArticle;
    private float prix;
    private Integer quantité;
    private String nomFournisseur;
}
