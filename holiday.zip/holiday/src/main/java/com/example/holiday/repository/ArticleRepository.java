package com.example.holiday.repository;

import com.example.holiday.model.Article;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ArticleRepository extends MongoRepository<Article, String> {

    @Query("{nomArticle:?0}")
    List<Article> findArticleByNomArticle(String nomArticle);

    List<Article> findByNomFournisseur(String nomFournisseur);
}
