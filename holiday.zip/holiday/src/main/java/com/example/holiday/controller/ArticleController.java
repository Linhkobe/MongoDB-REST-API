package com.example.holiday.controller;


import com.example.holiday.model.Article;
import com.example.holiday.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/articles")
public class ArticleController {

    @Autowired
    private ArticleService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Article createArticle(@RequestBody Article article) {
        return service.addArticle(article);
    }

    /// worked
    @GetMapping
    public List<Article> getArticle() {
        return service.findAllArticle();
    }

    /// worked and verified on browser
    @GetMapping("/{articleId}")
    public Article getArticle(@PathVariable String articleId) {
        return service.getArticleByArticleId(articleId);
    }

    /// worked and verified on browser
    @GetMapping("/fournisseur/{nomFournisseur}")
    public List<Article> findArticleUsingFournisseur(@PathVariable String nomFournisseur) {
        return service.getArticleByFournisseur(nomFournisseur);
    }

    /// worked
    @GetMapping("/nomArticle/{nomArticle}")
    public List<Article> findArticleByNomArticle(@PathVariable String nomArticle) {
        return service.getArticleByNomArticle(nomArticle);
    }

    /// work on postman and verified on browser
    @PutMapping
    public Article modifyArticle(@RequestBody Article article) {
        return service.updateArticle(article);
    }

    /// work on postman and verified on browser
    @DeleteMapping("/{articleId}")
    public  String deleteArticle(@PathVariable String articleId) {
        return service.deleteArticle(articleId);
    }
}
